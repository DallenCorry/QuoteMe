package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.lang.reflect.Array;
import java.util.*;

public class Controller {
    private Stage stage;
    private Scene scene;
    private Parent root;

    ArrayList<Question> questionsArr;
    ArrayList<Question> selectedQuestions;
    Scanner read;
    static int score = 0;
    int questionNum;
    static int numberOfQuestions;


    @FXML
    ToggleGroup answerGroup;
    @FXML
    Text quote, quotedPerson, quotedMovie, txtScore, questionNumber;
    @FXML
    RadioButton optionA, optionB, optionC, optionD;
    @FXML
    Button revealButton;

    public Controller() throws FileNotFoundException {
        questionsArr = new ArrayList<Question>();
        questionNum = 0;

        read = new Scanner(new File("/Users/student/Downloads/QuoteMeFinalProject/src/sample/quoteData"));
        while(read.hasNextLine()) {
            questionsArr.add(new Question(read.nextLine()));
        }
        read.close();
    }

    public void howToPlay() throws IOException {
        popupScreen("quoteMeHowToPlay.fxml");
    }

    public void options(ActionEvent event) throws IOException {
//        popupScreen("quoteMeOptions.fxml", event); //doesn't exist yet
        System.out.println("Not implemented yet.");
    }

    public void genFirstQuestion(int[] selectedMovies) {
        //get the correct questions from questionsArr
        selectedQuestions = genQuestions(questionsArr, selectedMovies);
        questionNum = 0;
        numberOfQuestions = selectedQuestions.size();

        //set the text
        Question q = selectedQuestions.get(questionNum);
        questionNumber.setText("Question # "+(questionNum+1));
        quote.setText(q.getQuote());
        quotedPerson.setText("-"+q.getSpeaker());
        quotedMovie.setText(q.getMovie());
        optionA.setText("A) " + q.getOptions()[0]);
        optionB.setText("B) " + q.getOptions()[1]);
        optionC.setText("C) " + q.getOptions()[2]);
        optionD.setText("D) " + q.getOptions()[3]);
    }

    public void enterAnswer(ActionEvent event) {
        String ans = "";
        try {
            ans = ((RadioButton) answerGroup.getSelectedToggle()).getText();


            ans = ans.substring(0,1);
            //check for right/wrong
            if (ans.equals(selectedQuestions.get(questionNum).getAnswer())) {
                score++;
            } else {
                System.out.println("Wrong. Correct answer is: "+selectedQuestions.get(questionNum).getAnswer());
            }
            //go to next question
            questionNum++;
            questionNumber.setText("Question # "+(questionNum+1));
            if (questionNum == numberOfQuestions) {
                changeScreen("quoteMeGameOver.fxml",event);
            } else {
                Question q = selectedQuestions.get(questionNum);

                quote.setText(q.getQuote());
                quotedPerson.setText("-" + q.getSpeaker());
                quotedMovie.setText(q.getMovie());
                optionA.setText("A) " + q.getOptions()[0]);
                optionB.setText("B) " + q.getOptions()[1]);
                optionC.setText("C) " + q.getOptions()[2]);
                optionD.setText("D) " + q.getOptions()[3]);

                answerGroup.getSelectedToggle().setSelected(false);
            }
        } catch(NullPointerException np){
            System.out.println("Nothing selected!!");
        } catch (Exception e) {
            System.out.println("Other exception:\n" + e.getLocalizedMessage());
        }

    }

    public void showScore() {
        txtScore.setText(score+" out of "+numberOfQuestions);
        revealButton.setVisible(false);
    }
    private void changeScreen(String sceneName, ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource(sceneName));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void popupScreen(String sceneName) throws IOException {
        Stage popStage = new Stage();
        Parent popRoot = FXMLLoader.load(getClass().getResource(sceneName));
        Scene popScene = new Scene(popRoot);
        popStage.setScene(popScene);
        popStage.show();
    }
    private ArrayList<Question> genQuestions(ArrayList<Question> questionsArr, int[] selectedMovies) {
        //TODO:
        // - Do this
        // - Add questions for each movie
        // - more questions per movie for harder difficulty
        // - shuffle the questions.
        ArrayList<Question> selectedQuestions = new ArrayList<Question>();
        for (int i=0; i<selectedMovies.length; i++) {
            selectedQuestions.add(questionsArr.get(selectedMovies[i]));//This line gets one line per movie.
        }
        System.out.println(selectedQuestions);
        randomizeInPlace(selectedQuestions);
        System.out.println(selectedQuestions);
        return selectedQuestions;
    }

    private ArrayList<Question> randomizeInPlace(ArrayList<Question> arr) {
        int n= arr.size();
        Random r = new Random();
        r.nextInt();
        for (int i=0; i<n; i++){
            Question temp = arr.get(i);
            int b = i+r.nextInt(n-i);
            arr.set(i,arr.get(b));
            arr.set(b, temp);
        }
        return arr;
    }
}
