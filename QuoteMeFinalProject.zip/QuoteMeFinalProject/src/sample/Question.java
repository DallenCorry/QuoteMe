package sample;

public class Question {
    private String quote;
    private String speaker;
    private String movie;
    private String[] options = new String[4];
    private String answer;

    Question(String list){
        String[] arr = list.split(";");
        if (arr.length != 8) {
            System.out.println("Err bad data" + list);
        } else {
            quote = arr[0];
            speaker = arr[1];
            movie = arr[2];
            options[0] = arr[3];
            options[1] = arr[4];
            options[2] = arr[5];
            options[3] = arr[6];
            answer = arr[7];
        }
    }

    public Question(String quote, String speaker, String movie, String[] options, String answer) {
        this.quote = quote;
        this.speaker = speaker;
        this.movie = movie;
        this.options = options;
        this.answer = answer;
    }

    public String getQuote() {
        return quote;
    }

    public String getSpeaker() {
        return speaker;
    }

    public String getMovie() {
        return movie;
    }

    public String[] getOptions() {
        return options;
    }

    public String getAnswer() {
        return answer;
    }
}
