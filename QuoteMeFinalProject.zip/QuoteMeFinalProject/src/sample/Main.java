package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Main extends Application {
    /*
    Quotes from the best movies!
    Napoleon Dynamite
    The Princess Bride
    Ferris Bueller's day off
    The Sandlot
    Monty Python and the holy Grail
    Nacho Libre
    The Emperor's new groove
    the Incredibles
    Mulan
    Star Wars
    Spaceballs

Maybe:
    **back to the future
    jurassic park
    *Shrek
    Aladdin
    Harry Potter
    kung fu panda
    Ghost busters
    home alone
    A christmas Story
    The goonies
    Top Gun
    the terminator

     */

    int pageNumber = 1;
    Stage mainStage = new Stage();
    BorderPane movieSelect = new BorderPane();
    StackPane MAINPANE = new StackPane();
    //Text pageText;

    @Override
    public void start(Stage primaryStage) throws Exception{
        FXMLLoader loader = new FXMLLoader();

        BorderPane startPane = loader.load(getClass().getResource("quoteMeMenu.fxml"));
        Button btnPlay = new Button("PLAY");
        btnPlay.setFont(Font.font(24));
        MAINPANE.getChildren().addAll(startPane, btnPlay);
        mainStage.setTitle("Menu");
        mainStage.setScene(new Scene(MAINPANE));
        mainStage.show();

        String[] Movies = {"The Emperor's New Groove", "Ferris Bueller's Day Off", "Forrest Gump", "How to Train Your Dragon", "The Incredibles", "Monty Python and the Holy Grail", "Mulan", "Nacho Libre", "Napoleon Dynamite", "The Princess Bride", "The Sandlot", "Space Balls", "Star Wars" };
        String[] movieImages = {"emperorsGroove.jpg", "ferrisBueller.jpeg", "forrestGump.png", "howToTrain.jpeg", "incredibles.jpeg", "montyPython.jpeg", "mulan.jpeg", "nachoLibre.jpeg", "napoleonDynamite.jpeg", "princessBride.jpg", "sandLot.jpeg", "spaceBalls.jpeg", "starWars.jpg"};
        int numPages = ((Movies.length-1)/8)+1;
        ArrayList<Integer> selectedMovieIDs = new ArrayList<Integer>();

        HBox msCenter = new HBox();
        Button btLeft = new Button("<--");
        Button btRight = new Button("-->");
        GridPane msGrid = new GridPane();

        RadioButton[] movieArr = new RadioButton[Movies.length];
        for (int i=0; i<movieArr.length; i++) {
            RadioButton temp = new RadioButton(Movies[i]);
            if (null != movieImages[i] && movieImages[i] != ""){
                Image temporaryAgain = new Image(movieImages[i]);
                ImageView tempImage = new ImageView(new Image (movieImages[i]));
                tempImage.setPreserveRatio(true);
                tempImage.setFitHeight(150);
                tempImage.setFitWidth(150);
                temp.setGraphic(tempImage);
                temp.setContentDisplay(ContentDisplay.TOP);
                temp.setAlignment(Pos.CENTER_LEFT);
                temp.setTextAlignment(TextAlignment.LEFT);
            }
            movieArr[i] = temp;
        }
        createGrid(msGrid, movieArr);

//        msGrid.setGridLinesVisible(true);
        btLeft.setVisible(pageNumber != 1);
        btRight.setVisible(pageNumber != numPages);
        msCenter.getChildren().addAll(btLeft, msGrid, btRight);
        msCenter.setAlignment(Pos.CENTER);
        msCenter.setSpacing(20);

        Text title = new Text("Select Movies");
        title.setFont(Font.font(32));
        title.setTextAlignment(TextAlignment.CENTER);

        VBox msBottom = new VBox();
        Text pageText = new Text("Page "+ pageNumber +" of " + numPages);
        ChoiceBox difficulty = new ChoiceBox<String>(FXCollections.observableArrayList("Easy", "Normal", "Hard"));
        difficulty.setValue("Normal");
        Button btnReady = new Button("  Ready  ");
        Text chooseText = new Text("Select 2 to 5 movies");
        msBottom.getChildren().addAll(pageText, difficulty, btnReady,chooseText);
        msBottom.setAlignment(Pos.CENTER);
        msBottom.setSpacing(5);
        msBottom .setPadding(new Insets(5,5,10,5));

        movieSelect.setTop(title);
        movieSelect.setCenter(msCenter);
        movieSelect.setBottom((msBottom));

        movieSelect.setAlignment(title, Pos.CENTER);
        movieSelect.setPrefHeight(500);
        movieSelect.setPrefWidth(850);

        btnPlay.setOnAction(e -> {
            Scene myScene = new Scene(movieSelect);
            mainStage.setScene(myScene);
            mainStage.show();
        });

        btRight.setOnAction(e -> {
            if (pageNumber < numPages) {
                pageNumber++;
                pageText.setText("Page " + pageNumber + " of " + numPages);
                createGrid(msGrid, movieArr);
            }
            btLeft.setVisible(pageNumber > 1);
            btRight.setVisible(pageNumber < numPages);
        });

        btLeft.setOnAction(e -> {
            if (pageNumber > 0) {
                pageNumber--;
                pageText.setText("Page " + pageNumber + " of " + numPages);
                createGrid(msGrid, movieArr);
            }
            btLeft.setVisible(pageNumber > 1);
            btRight.setVisible(pageNumber < numPages);
        });

        btnReady.setOnAction(e -> {
            //add all to arraylist
            selectedMovieIDs.clear();
            for (int i=0; i<movieArr.length; i++) {
                if (movieArr[i].isSelected()){
                    selectedMovieIDs.add(i);
                }
            }
            if (selectedMovieIDs.size()<2){// || selectedMovieIDs.size()>5){
                chooseText.setStyle("-fx-stroke: red");
            } else {
                Pane p;
                try {
                    //Controller.genFirstQuestion();

                    FXMLLoader temp = new FXMLLoader(getClass().getResource("quoteMeQuestion.fxml"));
                    p=temp.load();
                    int[] selectedMovies = new int[selectedMovieIDs.size()];
                    for(int i=0; i<selectedMovies.length; i++){
                        selectedMovies[i] = selectedMovieIDs.get(i);
                    }
                    ((Controller)temp.getController()).genFirstQuestion(selectedMovies);
                    Scene myScene = new Scene(p);
                    mainStage.setScene(myScene);
                    mainStage.show();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            }
        });

    }


    public static void main(String[] args) {
        launch(args);
    }

    public void createGrid(GridPane msGrid, RadioButton[] movieArr){
        msGrid.getChildren().clear();
        int j=0;
        int k=0;
        for(int i=(pageNumber-1) * 8; i < Math.min((8*pageNumber),movieArr.length); i++) {
            j++;
            if (i%4 == 0){
                j=0;
                k++;
            }
            msGrid.add(movieArr[i],j,k);
        }
    }
}
